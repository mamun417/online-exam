<div class="footer">
    <div class="pull-right">
        <strong></strong>
    </div>
    <div>
        <strong>Copyright</strong> Fictionsoft &copy; 2020
    </div>
</div>
