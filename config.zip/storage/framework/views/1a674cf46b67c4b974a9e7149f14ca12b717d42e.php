<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>medi-spark</title>
    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
</head>
<body class="gray-bg">
    <div class="loginColumns animated fadeInDown">
        <div class="row">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <hr/>
    </div>
</body>
</html>
<?php /**PATH G:\aziz\Laravel 2019\htdocs\Project2020\medi-spark\resources\views/auth/layouts/app.blade.php ENDPATH**/ ?>