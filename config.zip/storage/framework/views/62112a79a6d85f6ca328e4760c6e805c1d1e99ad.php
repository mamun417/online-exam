<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu nav-list" id="side-menu">
            <li class="nav-header ">
                <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="<?php echo e(url('backend/img/profile_small.jpg')); ?>" />
                             </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">David Williams</strong>
                             </span> <span class="text-muted text-xs block">Art Director <b class="caret"></b></span> </span> </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a href="<?php echo e(route('show.profile')); ?>">Profile</a></li>
                        <li><a href="<?php echo e(route('password.change')); ?>">Change Password</a></li>
                        <li class="divider"></li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                Log out
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
                <div class="logo-element">
                    IN+
                </div>
            </li>

            <li class="<?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
            </li>

            <li class="<?php echo e(Request::is('questionTemplate*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('questionTemplates.index')); ?>"><i class="fa fa-diamond"></i> <span class="nav-label">Question Template</span></a>
            </li>

            <li class="<?php echo e(Request::is('departments*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('departments.index')); ?>"><i class="fa fa-diamond"></i> <span class="nav-label">Departments</span></a>
            </li>

            <li class="<?php echo e(Request::is('subjects*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('subjects.index')); ?>"><i class="fa fa-book" aria-hidden="true"></i> <span class="nav-label">Subjects</span></a>
            </li>
            
            <li class="<?php echo e(Request::is('questions*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('questions.index')); ?>"><i class="fa fa-book" aria-hidden="true"></i> <span class="nav-label">Questions</span></a>
            </li>

            <!-- <li>
                <a href="<?php echo e(route('examinations.index')); ?>"><i class="fa fa-book" aria-hidden="true"></i> <span class="nav-label">Examinations</span></a>
            </li> -->
        </ul>
    </div>
</nav>
<?php /**PATH G:\aziz\Laravel 2019\htdocs\Project2020\medi-spark\resources\views/backend/element/sidebar.blade.php ENDPATH**/ ?>