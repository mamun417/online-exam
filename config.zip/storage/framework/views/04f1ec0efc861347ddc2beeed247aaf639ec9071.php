<div class="form-group"><label class="col-lg-2 control-label">Subject Name<span class="required-star"> *</span></label>
    <div class="col-lg-6">
        <input type="text" value="<?php echo e(isset($subject->name) ? $subject->name:old('name')); ?>" name="name" class="form-control">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group"><label class="col-lg-2 control-label">Subject Code<span class="required-star"> *</span></label>
    <div class="col-lg-6">
        <input type="text" value="<?php echo e(isset($subject->subject_code) ? $subject->subject_code:old('subject_code')); ?>" name="subject_code" class="form-control">
        <?php $__errorArgs = ['subject_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<?php /**PATH G:\aziz\Laravel 2019\htdocs\Project2020\medi-spark\resources\views/backend/subject/element.blade.php ENDPATH**/ ?>