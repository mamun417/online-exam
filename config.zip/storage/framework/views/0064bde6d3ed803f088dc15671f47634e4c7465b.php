<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Medi-Spark</title>

    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">

    

    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">

    <!-- Toastr style -->
    <link href="<?php echo e(asset('backend/css/plugins/toastr/toastr.min.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('backend/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('backend/js/extra-plugin/tokenize2/tokenize2.min.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('backend/css/custom_style.css')); ?>" rel="stylesheet">
</head>
<body>

<div id="wrapper">
    <?php echo $__env->make('backend.element.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div id="page-wrapper" class="gray-bg">

    <?php echo $__env->make('backend.element.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('backend.element.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<script src="<?php echo e(asset('backend/js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo e(asset('backend/js/inspinia.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/plugins/pace/pace.min.js')); ?>"></script>

<!-- iCheck -->
<script src="<?php echo e(asset('backend/js/plugins/iCheck/icheck.min.js')); ?>"></script>

<!-- Toastr -->
<script src="<?php echo e(asset('backend/js/plugins/toastr/toastr.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/js/extra-plugin/tokenize2/tokenize2.min.js')); ?>"></script>

<script>

    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });

    
    $(function () {

        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 2500
        };

        <?php if(session('successTMsg')): ?>
            toastr.success('<?php echo e(session('successTMsg')); ?>');
        <?php endif; ?>

        <?php if(session('errorTMsg')): ?>
            toastr.error('<?php echo e(session('errorTMsg')); ?>');
        <?php endif; ?>
    });

    //show confirm message when delete table row
    function deleteRow(rowId) {

        swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            type: "warning",
            showCancelButton: true,
            allowOutsideClick: true,
            confirmButtonColor: "#1ab394",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: true
        }, function () {
            document.getElementById('row-delete-form'+rowId).submit();
        });
    }
</script>

<?php echo $__env->yieldContent('custom-js'); ?>

</body>
</html>
<?php /**PATH G:\aziz\Laravel 2019\htdocs\Project2020\medi-spark\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>