<?php $__env->startSection('content'); ?>

    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Change Password</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>">Home</a>
                </li>
                <li>
                    <a href="">Profile</a>
                </li>
                <li class="active">
                    <strong>Change Password</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('password.update')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
							    <label class="col-lg-2 control-label">Password<span class="required-star"> *</span></label>
							    <div class="col-lg-6">
							        <input type="possword" name="password" class="form-control">
							        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							    </div>
							</div>

							<div class="form-group">
							    <label class="col-lg-2 control-label">Confirm Password<span class="required-star"> *</span></label>
							    <div class="col-lg-6">
							        <input type="password" name="password_confirmation" class="form-control"> 
							    </div>
							</div>

                            <div class="form-group">
                                <div class="col-lg-2"></div>
                                <div class="col-lg-10">
                                    <button class="btn btn-sm btn-primary pull-left m-t-n-xs" type="submit"><strong>Update</strong></button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\aziz\Laravel 2019\htdocs\Project2020\medi-spark\resources\views/backend/admin/change_password.blade.php ENDPATH**/ ?>